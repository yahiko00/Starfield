var dat = require('../src/index.js');
var gui = new dat.gui.GUI();
//var controller = gui.addController(colorController);
//controller.add('build', 0x00ff00);
var controller =  gui.addColor({x: 0xff0000}, 'x');
controller.name([
'<span class="toggle_enabled_edge"><input type="checkbox" name="checkbox" id="toggle_build" class="toggle" value="value">',
'<label for="toggle_build">Build</label></span>'
].join('\n'));

console.log(controller.__li.querySelector('input.toggle'));
console.log(controller.__li);
//console.log(controller);
